# Worklytics Project 

## Overview

Worklytics is a time tracking application built with Ruby on Rails. The system allows users to log their work hours, set weekly work goals, and view reports about their work patterns. The application has two main user roles: regular users who track their time, and administrators who can manage users and view aggregate reports.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows the classic Ruby on Rails MVC (Model-View-Controller) architecture:

- **Models**: Represent database tables and business logic (User, TimeLog, WorkGoal)
- **Views**: ERB templates that render the HTML UI 
- **Controllers**: Handle requests, interact with models, and render views

The application uses:
- PostgreSQL for the database
- Rails 6.0.4 on Ruby 2.7.4
- Bootstrap 4.6 for the frontend UI
- Chartkick and Groupdate for charts and analytics
- BCrypt for password authentication

## Key Components

### 1. User Authentication System

The application implements a custom authentication system using BCrypt:
- Session-based authentication
- Secure password handling with bcrypt
- Role-based authorization (admin vs regular users)

### 2. Time Logging

Core functionality that allows users to:
- Create, edit, and delete time logs
- Specify task descriptions, dates, start and end times
- View logs by date with calculated durations

### 3. Work Goals

Users can:
- Set weekly work hour goals
- Track progress toward these goals
- View historical goal achievement

### 4. Reporting

- Individual user reports with charts
- Admin overview reports across all users
- CSV export functionality for time log data

### 5. Admin Dashboard

Admin-specific features:
- User management (CRUD operations)
- System-wide analytics
- User activity monitoring

## Data Flow

1. **User Registration and Authentication**:
   - Users sign up or log in
   - System verifies credentials and establishes a session
   - Users are directed to appropriate dashboards based on role

2. **Time Logging Process**:
   - User enters time log details (task, date, times)
   - System calculates hours automatically
   - Data is stored and displayed in reports and dashboards
   
3. **Work Goal Management**:
   - Users set weekly goals (must start on Mondays)
   - System tracks progress against goals
   - Visualizations show achievement percentage

4. **Reporting and Analytics**:
   - Time logs are aggregated into charts and summaries
   - Admins can view system-wide statistics
   - Data can be filtered by date ranges and exported as CSV

## Database Schema

### Users
- `id`: Primary key
- `name`: User's full name
- `email`: Unique email address
- `password_digest`: Encrypted password
- `role`: Either 'admin' or 'user'
- Timestamps

### TimeLogs
- `id`: Primary key
- `user_id`: Foreign key to users
- `task_description`: Description of the work
- `date`: Date of the work
- `start_time`: When work started
- `end_time`: When work ended
- `total_hours`: Calculated duration
- Timestamps

### WorkGoals
- `id`: Primary key
- `user_id`: Foreign key to users
- `week_start_date`: Monday start date of the week
- `goal_hours`: Target work hours for the week
- Timestamps

## External Dependencies

- **PostgreSQL**: Database system
- **Bootstrap 4.6**: UI framework loaded via CDN
- **Font Awesome 5.15.3**: Icon library loaded via CDN
- **jQuery**: JavaScript library for Bootstrap components
- **Google Charts & Highcharts**: For data visualization

## Deployment Strategy

The application is configured to run on Replit with:
- Ruby module enabled
- PostgreSQL database
- Port 5000 for the web server
- Rails in production mode

The deployment process:
1. Bundle install to fetch Ruby dependencies
2. Database creation and migration
3. Seed data loading for initial users and sample data
4. Rails server startup on port 5000 bound to all interfaces

The application is ready to handle:
- User authentication
- Time tracking
- Goal setting
- Reporting functions
- Admin operations

## Development Workflow

When developing new features:
1. Create necessary database migrations
2. Implement or update models with validations and associations
3. Build controller actions with proper authorization
4. Create or modify views with Bootstrap styling
5. Add helper methods for view formatting
6. Test functionality manually

## Key Files to Understand

- `config/routes.rb`: Defines all application routes
- `app/models/`: Contains the application's data models and business logic
- `app/controllers/`: Contains controllers for both regular and admin functions
- `app/views/`: Contains all ERB templates organized by controller
- `db/migrations/`: Database schema definition files