class WorkGoalsController < ApplicationController
  before_action :require_user
  before_action :set_work_goal, only: [:edit, :update, :destroy]
  
  def index
    @work_goals = current_user.work_goals.order(week_start_date: :desc)
    @current_week_goal = current_user.current_week_goal
  end
  
  def new
    @work_goal = current_user.work_goals.build(week_start_date: Date.current.beginning_of_week)
  end
  
  def create
    @work_goal = current_user.work_goals.build(work_goal_params)
    
    if @work_goal.save
      flash[:success] = "Work goal was successfully created."
      redirect_to work_goals_path
    else
      render :new
    end
  end
  
  def edit
    # @work_goal is set by before_action
  end
  
  def update
    if @work_goal.update(work_goal_params)
      flash[:success] = "Work goal was successfully updated."
      redirect_to work_goals_path
    else
      render :edit
    end
  end
  
  def destroy
    @work_goal.destroy
    flash[:success] = "Work goal was successfully deleted."
    redirect_to work_goals_path
  end
  
  private
  
  def set_work_goal
    @work_goal = current_user.work_goals.find(params[:id])
  end
  
  def work_goal_params
    params.require(:work_goal).permit(:week_start_date, :goal_hours)
  end
end
