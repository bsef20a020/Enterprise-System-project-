class TimeLogsController < ApplicationController
  before_action :require_user
  before_action :set_time_log, only: [:edit, :update, :destroy]
  before_action only: [:edit, :update, :destroy] do
    authorize_user(@time_log.user)
  end
  
  def index
    @date = params[:date] ? Date.parse(params[:date]) : Date.current
    @time_logs = current_user.time_logs.for_date(@date).order(start_time: :asc)
    @total_hours = @time_logs.sum(:total_hours)
  end
  
  def new
    @time_log = current_user.time_logs.build(date: Date.current)
  end
  
  def create
    @time_log = current_user.time_logs.build(time_log_params)
    
    if @time_log.save
      flash[:success] = "Time log was successfully created."
      redirect_to time_logs_path(date: @time_log.date)
    else
      render :new
    end
  end
  
  def edit
    # @time_log is set by before_action
  end
  
  def update
    if @time_log.update(time_log_params)
      flash[:success] = "Time log was successfully updated."
      redirect_to time_logs_path(date: @time_log.date)
    else
      render :edit
    end
  end
  
  def destroy
    date = @time_log.date
    @time_log.destroy
    flash[:success] = "Time log was successfully deleted."
    redirect_to time_logs_path(date: date)
  end
  
  private
  
  def set_time_log
    @time_log = TimeLog.find(params[:id])
  end
  
  def time_log_params
    params.require(:time_log).permit(:task_description, :date, :start_time, :end_time)
  end
end
