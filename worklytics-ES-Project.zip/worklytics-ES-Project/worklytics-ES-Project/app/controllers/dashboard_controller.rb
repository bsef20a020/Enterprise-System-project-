class DashboardController < ApplicationController
  before_action :require_user
  
  def index
    # Get the current week's work goal
    @work_goal = current_user.current_week_goal
    
    # Get today's time logs
    @today_time_logs = current_user.time_logs.for_date(Date.current).order(start_time: :asc)
    @today_total_hours = @today_time_logs.sum(:total_hours)
    
    # Get this week's time logs
    @week_start = Date.current.beginning_of_week
    @week_end = Date.current.end_of_week
    @week_time_logs = current_user.time_logs.for_date_range(@week_start, @week_end)
    @week_total_hours = @week_time_logs.sum(:total_hours)
    
    # Get data for the daily hours chart (past 7 days)
    @past_week_start = Date.current - 6.days
    @daily_hours = current_user.time_logs.for_date_range(@past_week_start, Date.current)
                         .group(:date).sum(:total_hours)
                         
    # Weekly goals chart data - last 4 weeks
    @weekly_goals_data = {}
    4.times do |i|
      week_start = Date.current.beginning_of_week - (i * 7).days
      week_end = week_start + 6.days
      
      goal = current_user.work_goals.find_by(week_start_date: week_start)
      actual_hours = current_user.time_logs.for_date_range(week_start, week_end).sum(:total_hours)
      
      week_label = "Week of #{week_start.strftime('%b %d')}"
      @weekly_goals_data[week_label] = {
        goal: goal&.goal_hours || 0,
        actual: actual_hours
      }
    end
    
    @weekly_goals_data = @weekly_goals_data.sort.to_h
  end
end
