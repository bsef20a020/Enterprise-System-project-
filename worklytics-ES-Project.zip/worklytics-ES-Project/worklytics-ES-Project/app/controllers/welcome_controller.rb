class WelcomeController < ApplicationController
  # Skip authentication for this controller
  skip_before_action :require_user, raise: false
  
  def index
    if logged_in?
      redirect_to dashboard_path
    end
  end
end