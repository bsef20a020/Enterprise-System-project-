class Admin::ReportsController < ApplicationController
  before_action :require_admin
  
  def index
    @users = User.all.order(:name)
    @selected_user = params[:user_id].present? ? User.find(params[:user_id]) : nil
    
    @start_date = params[:start_date] ? Date.parse(params[:start_date]) : Date.current.beginning_of_month
    @end_date = params[:end_date] ? Date.parse(params[:end_date]) : Date.current
    
    @time_logs = TimeLog.for_date_range(@start_date, @end_date)
    @time_logs = @time_logs.for_user(@selected_user.id) if @selected_user
    
    @total_hours = @time_logs.sum(:total_hours)
    
    # Group data for charts
    @daily_hours = @time_logs.group(:date).sum(:total_hours)
    @user_hours = @time_logs.joins(:user).group('users.name').sum(:total_hours) unless @selected_user
    
    respond_to do |format|
      format.html
      format.csv { send_data generate_csv, filename: "time_report_#{Date.current}.csv" }
    end
  end
  
  private
  
  def generate_csv
    require 'csv'
    
    CSV.generate(headers: true) do |csv|
      # Add headers
      csv << ["User", "Date", "Task Description", "Start Time", "End Time", "Total Hours"]
      
      # Add data rows
      @time_logs.includes(:user).each do |log|
        csv << [
          log.user.name,
          log.date,
          log.task_description,
          log.start_time.strftime("%H:%M"),
          log.end_time.strftime("%H:%M"),
          log.total_hours
        ]
      end
      
      # Add summary row
      csv << ["Total", "", "", "", "", @total_hours]
    end
  end
end
