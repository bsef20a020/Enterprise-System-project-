class Admin::DashboardController < ApplicationController
  before_action :require_admin
  
  def index
    @total_users = User.count
    @regular_users = User.regular_users.count
    @total_time_logs = TimeLog.count
    
    # Get time logs for the current week
    @week_time_logs = TimeLog.this_week
    @week_total_hours = @week_time_logs.sum(:total_hours)
    
    # Get time logs for the current month
    @month_time_logs = TimeLog.this_month
    @month_total_hours = @month_time_logs.sum(:total_hours)
    
    # Get users with goals for the current week
    @users_with_goals = WorkGoal.current_week.count
    
    # Get top 5 users by logged hours this week
    @top_users_this_week = User.joins(:time_logs)
                              .where(time_logs: { date: Date.current.beginning_of_week..Date.current.end_of_week })
                              .group(:id)
                              .select('users.*, SUM(time_logs.total_hours) as total_hours')
                              .order('total_hours DESC')
                              .limit(5)
  end
end
