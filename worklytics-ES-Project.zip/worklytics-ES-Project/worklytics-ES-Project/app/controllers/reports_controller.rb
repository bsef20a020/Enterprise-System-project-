class ReportsController < ApplicationController
  before_action :require_user
  
  def index
    @start_date = params[:start_date] ? Date.parse(params[:start_date]) : Date.current.beginning_of_month
    @end_date = params[:end_date] ? Date.parse(params[:end_date]) : Date.current
    
    @time_logs = current_user.time_logs.for_date_range(@start_date, @end_date).order(date: :asc)
    @total_hours = @time_logs.sum(:total_hours)
    
    # Prepare data for charts
    @daily_hours = @time_logs.group(:date).sum(:total_hours)
    
    # Group by task description
    @task_distribution = @time_logs.group(:task_description).sum(:total_hours)
    
    respond_to do |format|
      format.html
      format.csv { send_data generate_csv, filename: "my_time_report_#{Date.current}.csv" }
    end
  end
  
  private
  
  def generate_csv
    require 'csv'
    
    CSV.generate(headers: true) do |csv|
      # Add headers
      csv << ["Date", "Task Description", "Start Time", "End Time", "Total Hours"]
      
      # Add data rows
      @time_logs.each do |log|
        csv << [
          log.date,
          log.task_description,
          log.start_time.strftime("%H:%M"),
          log.end_time.strftime("%H:%M"),
          log.total_hours
        ]
      end
      
      # Add summary row
      csv << ["Total", "", "", "", @total_hours]
    end
  end
end
