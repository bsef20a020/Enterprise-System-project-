class WorkGoal < ApplicationRecord
  belongs_to :user
  
  validates :week_start_date, presence: true
  validates :goal_hours, presence: true, numericality: { greater_than: 0 }
  validate :week_start_date_is_monday
  validates :week_start_date, uniqueness: { scope: :user_id, message: "You already have a goal for this week" }
  
  # Scope for current week
  scope :current_week, -> { where(week_start_date: Date.current.beginning_of_week) }
  
  # Get the week end date
  def week_end_date
    week_start_date + 6.days
  end
  
  # Calculate progress as a percentage
  def progress_percentage
    total_hours = user.time_logs.for_date_range(week_start_date, week_end_date).sum(:total_hours)
    return 0 if goal_hours == 0
    
    (total_hours / goal_hours * 100).round(1)
  end
  
  # Calculate hours remaining to reach goal
  def hours_remaining
    total_hours = user.time_logs.for_date_range(week_start_date, week_end_date).sum(:total_hours)
    [goal_hours - total_hours, 0].max.round(1)
  end
  
  private
  
  def week_start_date_is_monday
    return if week_start_date.blank?
    
    unless week_start_date.monday?
      errors.add(:week_start_date, "must be a Monday")
    end
  end
end
