class TimeLog < ApplicationRecord
  belongs_to :user
  
  validates :task_description, presence: true
  validates :date, presence: true
  validates :start_time, presence: true
  validates :end_time, presence: true
  validate :end_time_after_start_time
  
  before_save :calculate_total_hours
  
  # Scopes for filtering
  scope :for_date, ->(date) { where(date: date) }
  scope :for_date_range, ->(start_date, end_date) { where(date: start_date..end_date) }
  scope :for_user, ->(user_id) { where(user_id: user_id) }
  
  # Get time logs for the current week
  scope :this_week, -> { where(date: Date.current.beginning_of_week..Date.current.end_of_week) }
  
  # Get time logs for the current month
  scope :this_month, -> { where(date: Date.current.beginning_of_month..Date.current.end_of_month) }
  
  private
  
  def end_time_after_start_time
    return if start_time.blank? || end_time.blank?
    
    if end_time <= start_time
      errors.add(:end_time, "must be after start time")
    end
  end
  
  def calculate_total_hours
    return if start_time.blank? || end_time.blank?
    
    # Calculate the duration in hours
    duration = (end_time - start_time) / 1.hour
    self.total_hours = duration.round(2)
  end
end
