class User < ApplicationRecord
  has_secure_password
  
  has_many :time_logs, dependent: :destroy
  has_many :work_goals, dependent: :destroy
  
  validates :name, presence: true
  validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :role, presence: true, inclusion: { in: ['admin', 'user'] }
  
  # Scope for admins
  scope :admins, -> { where(role: 'admin') }
  
  # Scope for regular users
  scope :regular_users, -> { where(role: 'user') }
  
  def admin?
    role == 'admin'
  end
  
  # Calculate total hours worked for a specific time period
  def total_hours_for_period(start_date, end_date)
    time_logs.where(date: start_date..end_date).sum(:total_hours)
  end
  
  # Calculate total hours worked for the current week
  def total_hours_this_week
    start_date = Date.current.beginning_of_week
    end_date = Date.current.end_of_week
    total_hours_for_period(start_date, end_date)
  end
  
  # Get the current week's work goal
  def current_week_goal
    start_date = Date.current.beginning_of_week
    work_goals.find_by(week_start_date: start_date)
  end
  
  # Calculate progress towards weekly goal as a percentage
  def weekly_goal_progress
    goal = current_week_goal
    return 0 unless goal&.goal_hours && goal.goal_hours > 0
    
    (total_hours_this_week / goal.goal_hours * 100).round(1)
  end
end
