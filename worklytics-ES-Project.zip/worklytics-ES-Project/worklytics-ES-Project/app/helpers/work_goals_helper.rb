module WorkGoalsHelper
  # Format week range for display
  def format_week_range(start_date)
    end_date = start_date + 6.days
    "#{start_date.strftime('%b %d')} - #{end_date.strftime('%b %d, %Y')}"
  end
  
  # CSS class for progress percentage
  def progress_class(percentage)
    if percentage >= 100
      "bg-success"
    elsif percentage >= 70
      "bg-info"
    elsif percentage >= 40
      "bg-warning"
    else
      "bg-danger"
    end
  end
  
  # Progress message based on percentage
  def progress_message(percentage)
    if percentage >= 100
      "Goal achieved!"
    elsif percentage >= 70
      "Almost there!"
    elsif percentage >= 40
      "Making progress"
    else
      "Just starting"
    end
  end
end
