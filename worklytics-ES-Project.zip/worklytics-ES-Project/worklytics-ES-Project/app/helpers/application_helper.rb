module ApplicationHelper
  # Format date for display
  def format_date(date)
    date.strftime("%B %d, %Y")
  end
  
  # Format time for display
  def format_time(time)
    time.strftime("%H:%M")
  end
  
  # Format date and time for display
  def format_datetime(datetime)
    datetime.strftime("%B %d, %Y at %H:%M")
  end
  
  # Page title helper
  def full_title(page_title = '')
    base_title = "Worklytics"
    page_title.empty? ? base_title : "#{page_title} | #{base_title}"
  end
  
  # Format hours (add 'hr' or 'hrs' suffix)
  def format_hours(hours)
    "#{hours} #{hours == 1 ? 'hr' : 'hrs'}"
  end
  
  # Bootstrap class for flash messages
  def flash_class(level)
    case level
    when 'notice', 'success' then "alert alert-success"
    when 'error', 'alert'    then "alert alert-danger"
    when 'warning'           then "alert alert-warning"
    else "alert alert-info"
    end
  end
end
