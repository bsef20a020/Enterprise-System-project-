module TimeLogsHelper
  # Calculate duration in hours between two times
  def duration_in_hours(start_time, end_time)
    return nil unless start_time && end_time
    
    duration = (end_time - start_time) / 1.hour
    duration.round(2)
  end
  
  # Get day of week name
  def day_name(date)
    date.strftime("%A")
  end
  
  # CSS class based on hours worked
  def hours_css_class(hours)
    if hours < 4
      "text-danger"
    elsif hours < 8
      "text-warning"
    else
      "text-success"
    end
  end
end
