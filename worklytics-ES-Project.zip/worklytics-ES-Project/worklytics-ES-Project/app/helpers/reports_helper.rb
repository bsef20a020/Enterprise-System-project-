module ReportsHelper
  # Format duration for reports
  def format_duration(total_hours)
    hours = total_hours.to_i
    minutes = ((total_hours - hours) * 60).round
    
    if hours > 0 && minutes > 0
      "#{hours}h #{minutes}m"
    elsif hours > 0
      "#{hours}h"
    else
      "#{minutes}m"
    end
  end
  
  # Helper to get week number for a date
  def week_number(date)
    date.strftime("%U").to_i
  end
  
  # Get color for chart based on index
  def chart_color(index)
    colors = ["#007bff", "#28a745", "#17a2b8", "#ffc107", "#dc3545", "#6610f2"]
    colors[index % colors.length]
  end
  
  # Format percentage
  def format_percentage(value, total)
    return 0 if total == 0
    percentage = (value.to_f / total.to_f * 100).round(1)
    "#{percentage}%"
  end
end
