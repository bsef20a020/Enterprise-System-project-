// Custom chart configurations
document.addEventListener('turbolinks:load', function() {
  // Set default chart colors
  Chartkick.options = {
    colors: ["#007bff", "#28a745", "#17a2b8", "#ffc107", "#dc3545", "#6610f2"]
  };
  
  // Setup chart animation
  if (typeof Chart !== 'undefined') {
    Chart.defaults.global.animation.duration = 1000;
    Chart.defaults.global.legend.position = 'bottom';
    Chart.defaults.global.responsive = true;
    Chart.defaults.global.maintainAspectRatio = false;
  }
});
