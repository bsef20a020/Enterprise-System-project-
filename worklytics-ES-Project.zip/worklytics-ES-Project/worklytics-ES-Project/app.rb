require 'sinatra'

# Simple app to preview Worklytics functionality
class WorklyticsPreview < Sinatra::Base
  set :port, 5000
  set :bind, '0.0.0.0'
  
  get '/' do
    erb :index
  end
  
  get '/login' do
    erb :login
  end
  
  get '/signup' do
    erb :signup
  end
  
  get '/dashboard' do
    erb :dashboard
  end
end

# Views
__END__

@@ layout
<!DOCTYPE html>
<html>
  <head>
    <title>Worklytics - Time Tracking System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container">
        <a class="navbar-brand" href="/">Worklytics</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="/login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/signup">Sign Up</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <div class="container mt-4">
      <%= yield %>
    </div>
    
    <!-- Bootstrap JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
  </body>
</html>

@@ index
<div class="jumbotron text-center">
  <h1 class="display-4">Welcome to Worklytics</h1>
  <p class="lead">Your complete time tracking solution</p>
  <hr class="my-4">
  <p>Track your work hours, set goals, and boost your productivity with our easy-to-use platform.</p>
  <div class="mt-4">
    <a href="/login" class="btn btn-primary btn-lg mr-2">Login</a>
    <a href="/signup" class="btn btn-outline-primary btn-lg">Sign Up</a>
  </div>
</div>

<div class="row mt-5">
  <div class="col-md-4">
    <div class="card mb-4">
      <div class="card-body text-center">
        <i class="fas fa-clock fa-3x mb-3 text-primary"></i>
        <h3 class="card-title">Track Time</h3>
        <p class="card-text">Log your daily work hours with detailed task descriptions.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mb-4">
      <div class="card-body text-center">
        <i class="fas fa-chart-line fa-3x mb-3 text-primary"></i>
        <h3 class="card-title">Set Goals</h3>
        <p class="card-text">Create weekly work hour goals and track your progress.</p>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mb-4">
      <div class="card-body text-center">
        <i class="fas fa-chart-pie fa-3x mb-3 text-primary"></i>
        <h3 class="card-title">View Reports</h3>
        <p class="card-text">Get insights into your productivity with detailed reports.</p>
      </div>
    </div>
  </div>
</div>

@@ login
<div class="row">
  <div class="col-md-6 mx-auto">
    <div class="card">
      <div class="card-header bg-primary text-white">
        <h4>Login</h4>
      </div>
      <div class="card-body">
        <form action="/login" method="post">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
          </div>
          
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
          </div>
          
          <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block">Login</button>
          </div>
        </form>
      </div>
      <div class="card-footer text-center">
        Don't have an account? <a href="/signup">Sign Up</a>
      </div>
    </div>
  </div>
</div>

@@ signup
<div class="row">
  <div class="col-md-6 mx-auto">
    <div class="card">
      <div class="card-header bg-success text-white">
        <h4>Sign Up</h4>
      </div>
      <div class="card-body">
        <form action="/signup" method="post">
          <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name">
          </div>
          
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
          </div>
          
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Choose a password">
          </div>
          
          <div class="form-group">
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm your password">
          </div>
          
          <div class="form-group">
            <button type="submit" class="btn btn-success btn-block">Create Account</button>
          </div>
        </form>
      </div>
      <div class="card-footer text-center">
        Already have an account? <a href="/login">Login</a>
      </div>
    </div>
  </div>
</div>

@@ dashboard
<div class="row mb-4">
  <div class="col-md-12">
    <h2>Welcome to your Dashboard</h2>
    <p class="lead">Track your productivity and manage your time effectively</p>
  </div>
</div>

<div class="row mb-4">
  <div class="col-md-4">
    <div class="card border-primary">
      <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0">Today's Work</h5>
      </div>
      <div class="card-body">
        <h2 class="text-center mb-4">4.5 hrs</h2>
        <p class="card-text">You've logged 4.5 hours today across 3 tasks.</p>
        <a href="#" class="btn btn-outline-primary btn-sm btn-block">View Details</a>
      </div>
    </div>
  </div>
  
  <div class="col-md-4">
    <div class="card border-success">
      <div class="card-header bg-success text-white">
        <h5 class="card-title mb-0">Weekly Goal</h5>
      </div>
      <div class="card-body">
        <div class="text-center mb-3">
          <h4>28.5 / 40 hrs</h4>
          <div class="progress">
            <div class="progress-bar bg-success" role="progressbar" style="width: 71%" aria-valuenow="71" aria-valuemin="0" aria-valuemax="100">71%</div>
          </div>
        </div>
        <p class="card-text">You're on track to meet your weekly goal!</p>
        <a href="#" class="btn btn-outline-success btn-sm btn-block">Manage Goals</a>
      </div>
    </div>
  </div>
  
  <div class="col-md-4">
    <div class="card border-info">
      <div class="card-header bg-info text-white">
        <h5 class="card-title mb-0">Quick Actions</h5>
      </div>
      <div class="card-body">
        <div class="list-group">
          <a href="#" class="list-group-item list-group-item-action">
            <i class="fas fa-plus-circle mr-2"></i> Log Time
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            <i class="fas fa-chart-bar mr-2"></i> View Reports
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            <i class="fas fa-tasks mr-2"></i> Manage Tasks
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title mb-0">Weekly Hours</h5>
      </div>
      <div class="card-body">
        <div class="chart-container" style="height: 300px; position: relative;">
          <!-- Placeholder for chart -->
          <div style="height: 100%; display: flex; align-items: center; justify-content: center; background-color: #f8f9fa;">
            <div class="text-center">
              <div style="width: 100%; height: 200px; background-image: linear-gradient(to right, #e9ecef 0%, #ced4da 20%, #e9ecef 40%); background-size: 200% 100%; animation: loading 1.5s infinite linear;"></div>
              <p class="mt-3 text-muted">Weekly hours chart would appear here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-md-4">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title mb-0">Recent Time Logs</h5>
      </div>
      <div class="card-body p-0">
        <ul class="list-group list-group-flush">
          <li class="list-group-item">
            <strong>Project planning</strong>
            <p class="mb-1">Today, 9:00 AM - 10:30 AM (1.5 hrs)</p>
          </li>
          <li class="list-group-item">
            <strong>Client meeting</strong>
            <p class="mb-1">Today, 11:00 AM - 12:00 PM (1 hr)</p>
          </li>
          <li class="list-group-item">
            <strong>Development</strong>
            <p class="mb-1">Today, 1:00 PM - 4:30 PM (3.5 hrs)</p>
          </li>
          <li class="list-group-item">
            <strong>Documentation</strong>
            <p class="mb-1">Yesterday, 2:00 PM - 5:00 PM (3 hrs)</p>
          </li>
        </ul>
      </div>
      <div class="card-footer">
        <a href="#" class="btn btn-sm btn-outline-secondary btn-block">View All Time Logs</a>
      </div>
    </div>
  </div>
</div>

<style>
@keyframes loading {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
</style>