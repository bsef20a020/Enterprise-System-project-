class CreateTimeLogs < ActiveRecord::Migration[6.0]
  def change
    create_table :time_logs do |t|
      t.references :user, null: false, foreign_key: true
      t.string :task_description, null: false
      t.date :date, null: false
      t.time :start_time, null: false
      t.time :end_time, null: false
      t.decimal :total_hours, precision: 5, scale: 2, null: false

      t.timestamps
    end
    add_index :time_logs, [:user_id, :date]
  end
end
