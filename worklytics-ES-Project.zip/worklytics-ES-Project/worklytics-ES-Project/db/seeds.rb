# Create admin user
admin = User.create!(
  name: 'Admin User',
  email: 'admin@example.com',
  password: 'password',
  password_confirmation: 'password',
  role: 'admin'
)

puts "Created admin user: #{admin.email}"

# Create regular user
user = User.create!(
  name: 'Regular User',
  email: 'user@example.com',
  password: 'password',
  password_confirmation: 'password',
  role: 'user'
)

puts "Created regular user: #{user.email}"

# Create sample time logs for the regular user
today = Date.current
this_week_start = today.beginning_of_week

# Time logs for today
TimeLog.create!(
  user: user,
  task_description: 'Project planning',
  date: today,
  start_time: '09:00',
  end_time: '10:30',
  total_hours: 1.5
)

TimeLog.create!(
  user: user,
  task_description: 'Client meeting',
  date: today,
  start_time: '11:00',
  end_time: '12:00',
  total_hours: 1.0
)

TimeLog.create!(
  user: user,
  task_description: 'Development',
  date: today,
  start_time: '13:00',
  end_time: '16:30',
  total_hours: 3.5
)

puts "Created #{TimeLog.count} time logs for today"

# Create time logs for previous days this week
(1..4).each do |days_ago|
  date = today - days_ago.days
  
  # Morning tasks
  TimeLog.create!(
    user: user,
    task_description: ['Email & planning', 'Team meeting', 'Client call', 'Documentation'].sample,
    date: date,
    start_time: '09:00',
    end_time: '12:00',
    total_hours: 3.0
  )
  
  # Afternoon tasks
  TimeLog.create!(
    user: user,
    task_description: ['Development', 'Code review', 'Bug fixes', 'Testing'].sample,
    date: date,
    start_time: '13:00',
    end_time: '17:00',
    total_hours: 4.0
  )
end

puts "Created time logs for previous days"

# Create weekly goal for the current week
WorkGoal.create!(
  user: user,
  week_start_date: this_week_start,
  goal_hours: 40.0
)

puts "Created work goal for current week"

# Create weekly goal for previous weeks
(1..3).each do |weeks_ago|
  week_start = this_week_start - weeks_ago.weeks
  
  WorkGoal.create!(
    user: user,
    week_start_date: week_start,
    goal_hours: 40.0
  )
  
  # Add some time logs for the previous weeks too
  (0..4).each do |day_offset|
    date = week_start + day_offset.days
    
    TimeLog.create!(
      user: user,
      task_description: ['Development', 'Meetings', 'Documentation', 'Planning', 'Testing'].sample,
      date: date,
      start_time: '09:00',
      end_time: '17:00',
      total_hours: rand(5.0..8.0).round(1)
    )
  end
end

puts "Created work goals and time logs for previous weeks"

puts "Seed data creation complete!"
