require_relative 'boot'

require 'rails/all'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Worklytics
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 6.0

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration can go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded after loading
    # the framework and any gems in your application.
    
    # Set time zone
    config.time_zone = 'UTC'
    
    # Set default locale
    config.i18n.default_locale = :en
    
    # Don't generate system test files.
    config.generators.system_tests = nil
    
    # Use SQL instead of Active Record's schema dumper when creating the database.
    # This is necessary if your schema can't be completely captured by the schema dumper.
    config.active_record.schema_format = :sql
    
    # Configure sensitive parameters which will be filtered from the log file.
    config.filter_parameters += [:password, :password_confirmation]
    
    # Enable the asset pipeline
    config.assets.enabled = true
    
    # Rails 6.0 defaults to the port 3000. Let's change it to 5000 to match our requirement
    if Rails.env.development? || Rails.env.production?
      config.webpacker.dev_server.port = 5000
    end
  end
end
