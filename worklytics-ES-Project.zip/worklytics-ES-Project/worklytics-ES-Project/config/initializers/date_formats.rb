# Custom date and time formats
Date::DATE_FORMATS[:default] = '%Y-%m-%d'
Time::DATE_FORMATS[:default] = '%H:%M'

# Common formats
Date::DATE_FORMATS[:month_day_year] = '%B %d, %Y'
Date::DATE_FORMATS[:month_day] = '%B %d'
Date::DATE_FORMATS[:short_date] = '%b %d, %Y'
Date::DATE_FORMATS[:day_month_year] = '%d %b %Y'
Date::DATE_FORMATS[:weekday] = '%A'
Date::DATE_FORMATS[:weekday_month_day] = '%A, %B %d'

# Time formats
Time::DATE_FORMATS[:time_only] = '%H:%M'
Time::DATE_FORMATS[:time_with_seconds] = '%H:%M:%S'
Time::DATE_FORMATS[:time_with_zone] = '%H:%M %Z'
Time::DATE_FORMATS[:short_time] = '%I:%M %p'
Time::DATE_FORMATS[:long_time] = '%I:%M:%S %p'

# Combined formats
Time::DATE_FORMATS[:short_datetime] = '%b %d, %Y %H:%M'
Time::DATE_FORMATS[:long_datetime] = '%B %d, %Y at %H:%M'
Time::DATE_FORMATS[:full_datetime] = '%A, %B %d, %Y at %I:%M %p'
