Rails.application.routes.draw do
  # Root path - welcomes users to the application
  root 'welcome#index'
  
  # Session routes
  get 'login', to: 'sessions#new'
  post 'login', to: 'sessions#create'
  delete 'logout', to: 'sessions#destroy'
  
  # User registration
  get 'signup', to: 'users#new'
  resources :users, only: [:new, :create, :edit, :update]
  
  # Dashboard for regular users
  get 'dashboard', to: 'dashboard#index'
  
  # Regular user resources
  resources :time_logs
  resources :work_goals
  resources :reports, only: [:index]
  
  # Admin namespace for admin-specific controllers
  namespace :admin do
    get 'dashboard', to: 'dashboard#index'
    resources :users
    resources :reports, only: [:index]
  end
  
  # Catch-all route for invalid routes
  match '*path', to: 'application#not_found', via: :all
end
