class Task < ApplicationRecord
  belongs_to :project
end
