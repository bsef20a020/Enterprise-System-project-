class DashboardController < ApplicationController
  before_action :require_login

  def index
    @projects = current_user.projects.includes(:tasks)
    @task_counts = Task.group_by_day(:created_at).count
  end
end
