Rails.application.routes.draw do
  root 'sessions#new'

  resources :users, only: [:new, :create]
  resources :sessions, only: [:new, :create, :destroy]
  resources :projects do
    resources :tasks, only: [:create]
  end

  get '/dashboard', to: 'dashboard#index', as: 'dashboard'
  get '/login', to: 'sessions#new'
  delete '/logout', to: 'sessions#destroy'
end
